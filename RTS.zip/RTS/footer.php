
<div id='footer'  class='row'>
<div id="footerImage" class='col-lg-2 col-md-2 col-sm-2 col-xs-2'>
<img src="images/logo.png" alt="Company Logo" class='img-responsive' />
</div>

<section id="contactsUs" class='col-lg-4 col-md-4 col-sm-5 col-xs-5'>
Address:<br />
Range Tents Services Limited<br />
P.0 BOX 75486 KAMPALA, Uganda<br />
Wakaliga Road near Lubiri SS<br />
AND<br />
Nalukolongo<br />
Opp. Bukoola Chemical Industries<br />
<i class='fa fa-phone'> Tel: 0703 531256/ 0756 249696 <br /></i>
Email: <a href='mailto:rangetents@gmail.com'>rangetents@gmail.com</a>
</section>
<section class='col-lg-4 col-md-4 col-sm-5 col-xs-5'>
Range Tents limited specialises in fabricating tents and camping equipments tailored to customers needs and conditions. We also offer rental services for chairs and tents for the time as required by the client. We can deliver the goods to the location where the customer needs them.
</section>
<div class='col-lg-2 col-md-2 col-sm-12 col-xs-12'>
<a href='https://www.facebook.com/rangeSevices' title="Like us on facebook"><i class='fa fa-facebook-official fa-4x '></i></a> &nbsp;&nbsp;
<a href='https://www.youtube.com/watch?v=V03A4mrlnhc&feature=youtu.be' title="Follow us on you tube"><i class='fa fa-youtube fa-4x'></i></a>&nbsp;&nbsp;
<a href='mailto:rangetents@gmail.com'><i class='fa fa-envelope fa-4x' title="Send us an email"></i></a>&nbsp;&nbsp;
</div>
</div>
<div style='background-color:#856; color:yellow;' class='row' >
<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12' style='text-align:centre;' >

<div id="myModal" class="modal fade" >
    <div class="modal-dialog">
      <div class="modal-content">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h2 class="modal-title" id="myModalLabel" style='color:blue;'><b>The Development Team</b></h2>
        </div>
        <div class="modal-body">
		<table class='table table-bordered' style=' color:blue; '>
		<tr bgcolor='#ccc'><th>Name</th><th>Telephone Contact</th><th>Email</th></tr>
		<tr><td>Kasumba Robert</td><td>+256752615075</td><td>robein@ymail.com</td></tr>
		<tr><td>Byarugaba Steven</td><td>+256706440588</td><td>byarus45@gmail.com</td></tr>
		<tr><td>Tumwesigye Eugene</td><td>+256758292849</td><td>regeneowak@hotmail.com</td></tr>
		<tr><td>Mayani Edith Martha</td><td>+256701754599</td><td>marthamayani@gmail.com</td></tr>
		<tr><td>Ainekirabo Mbabazi</td><td>+256757028029</td><td>mbabaziainekirabo@gmail.com</td></tr>
		<tr><td>Rutale Ivan</td><td>+256705878284</td><td>paulivan568@gmail.com</td></tr>
		</table>
		</div>
		
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" >Close</button>
        </div>
	</div>
	</div>
</div>
<center>&copy;2015. All rights reserved to Range Tents Services Limited| <a href='#' data-toggle="modal" data-target="#myModal"> Contact Developers</a></center>

</div>
<div id='dynamic'></div>
