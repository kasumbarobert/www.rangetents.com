
<div id='footer' style='margin-bottom:2%; padding:0px;'>
<table width='100%' border='1' ><tr><td>
<aside id="footerImage" style='padding-left:2%; padding-top:2%;'>
<img src="../images/logo.png" alt="Company Logo" width="90%" height="70%" />
</aside></td>
<td class='footer' width='30%'>
<section id="contactsUs" style='padding-top:2%;'>
Address:<br />
Range Tents Services Limited<br />
P.0 BOX 75486 KAMPALA, Uganda<br />
Wakaliga Road near Lubiri SS<br />
AND<br />
Nalukolongo<br />
Opp. Bukoola Chemical Industries<br />
Tel: 0703 531256/ 0756 249696<br />
</section></td>
<td width='30%' class='footer'>
Range Tents limited specialises in fabricating tents and camping equipments tailored to customers needs and conditions. We also offer rental services for chairs and tents for the time as required by the client. We can deliver the goods to the location where the customer needs them.
</td>
<td class='footer'>
<aside id="footerlinks" name='footerlinks' style=' padding-right:10%; padding-left:5%;'>
<ul style='list-style:none;'>
<li><a href=''>About us</a></li>
<li><a href='Contact us.php'>Contact us</a></li>
</ul>
<a href='https://www.facebook.com/rangeSevices'><img src='../images/Like us on facebook.png' alt="facebook" width='20%' height='20%' /></a>Like us on <a href='https://www.facebook.com/rangeSevices'>Facebook</a>
</aside></td></tr>
<tr><td colspan='4' align='center' style='background-color:#856; color:yellow;'>&copy;2015. All rights reserved to Range Tents Services Limited| <a href=''>Contact Developers</a></td>
</table>
</div>
