
<div id="header" style='border-radius:20px;'>
<table align="center">
<tr ><td><img src="../images/logo.png" alt="Company Logo" width="70%" height="50%" /></td><td align="center">
<span class="company_name" style='font-size:4em;'><b>RANGE TENTS LTD</b></span>
</td></tr>
</table>
</div>
<div style='width:100%;'>
<div id="menu" style='float:left;width:60%;'>
<nav style='color:blue;'><a href="index.php">Home </a> |
</nav>
</div> 
</div>
